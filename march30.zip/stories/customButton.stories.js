import React from "react";
import CustomButton from "../comps/customButton";
import Header from "../comps/header";



export default {
title: "Custom Button",
component: CustomButton,

}

export const MyCustomButton = () =>
<CustomButton/>
export const PageWithCustomButtons = () =>
<div>

<Header
    fontsize = {15}
    color= "green"
    onMouseOver={cancelClick}
/>

<Header
    fontsize = {25}
    color= "red"
    onMouseOver={OkClick}
/>


<CustomButton 
color="#999"
text="OK"
onClick={OkClick}
/>
<CustomButton 
color="#3F5"
text="CANCEL"
onClick={cancelClick}/>
<CustomButton 
color="#F3F"
text="SUBMIT"/>
<CustomButton text="Menu"/>
</div>


function cancelClick(){
    alert("cancel");
}

function OkClick(){
    alert("OK");
}