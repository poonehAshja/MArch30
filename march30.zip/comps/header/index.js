import React from "react";
import "./header.css";

const Header = ({fontSize, color, onMouseOver}) => <div 
style={{backgroundColor:color}}
className="header"
onMouseOver={onMouseOver}>
    <h1>HEADER</h1>
</div>

function MouseOver(){
    alert("mouse is over");
}

Header.defaultProps = {
    fontSize:12,
    color:"#000",
    onMouseOver:MouseOver
}


export default Header;
